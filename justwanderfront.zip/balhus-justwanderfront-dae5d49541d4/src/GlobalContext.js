
import  { createContext } from 'react';
 
const GlobalContext = createContext(null);
 
export default GlobalContext;