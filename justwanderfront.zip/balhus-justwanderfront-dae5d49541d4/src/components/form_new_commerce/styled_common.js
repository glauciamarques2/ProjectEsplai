import styled from 'styled-components';


const TitolContainer = styled.div`
    padding: 20px 0;
    display: flex;
    justify-content: space-between;
`;



export {TitolContainer};