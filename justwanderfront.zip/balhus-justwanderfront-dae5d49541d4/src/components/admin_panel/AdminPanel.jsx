function AdminPanel() {

    return (
        <>
            <h1>Revisiones</h1>
        </>
    )
}

export default AdminPanel;