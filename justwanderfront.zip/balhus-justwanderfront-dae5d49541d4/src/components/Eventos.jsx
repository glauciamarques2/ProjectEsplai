function Eventos(){
    return(
        <div style={{margin: "100px"}}>
        <h1>Eventos</h1>
        </div>
    )
}

export default Eventos;